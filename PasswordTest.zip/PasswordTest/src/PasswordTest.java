import java.util.Scanner;
/*

/**
 
 * @author PROMISE
 */

public class PasswordTest {

        public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        System.out.print("Enter your username: ");
        String username = input.nextLine();
       
        Scanner input1 = new Scanner(System.in);
        
        System.out.print("Enter your password: ");
        String password = input1.nextLine();
        
        Scanner input2 = new Scanner(System.in);
        
        System.out.print("Confirm password: ");
        String password1 = input2.nextLine();
       
         while(!password1.equals(password)){    
            System.out.println("Password don't match!");
            System.out.print("Please confirm your password: ");
            password1 = input2.nextLine();
        }                
        System.out.print("Continue");
    }
}
